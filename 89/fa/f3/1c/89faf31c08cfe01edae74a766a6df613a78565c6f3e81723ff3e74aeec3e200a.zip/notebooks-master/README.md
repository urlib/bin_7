# [Notebook](http://gestyy.com/w1Ilds)

# 欢迎您，访客
[![](https://cdn.jsdelivr.net/gh/lkpo0v/5n@master/gh/favicon.ico)](https://bit.ly/ark-github)
[![](https://cdn.jsdelivr.net/gh/lkpo0v/5n@master/zh/favicon.ico)](https://bit.ly/ark-zhihu)
[![](https://cdn.jsdelivr.net/gh/lkpo0v/5n@master/41939.png)](https://bit.ly/ark-lg)
[![](https://cdn.jsdelivr.net/gh/lkpo0v/5n@master/favicon.ico)](https://bit.ly/ark-yy)
[![](https://cdn.jsdelivr.net/gh/lkpo0v/5n@master/wiki-32/wikipedia.png)](https://bit.ly/ark-wiki)

------------

> [知乎专栏：OI随想 | Ark's Blog](https://bit.ly/ark-zl)

**文章推荐**
* [**【洛谷日报#157】快速入手拓扑排序** - 方舟的文章 - 知乎](https://bit.ly/lgrb157)

* [**最短路的三种算法（Floyd、Dijkstra、SPFA）** - 方舟的文章 - 知乎](https://bit.ly/zdldsztj)

* [**AtCoder Regular Contest 084 D - Small Multiple** - 方舟的文章 - 知乎](https://bit.ly/atc-084d)
