#include<bits/stdc++.h>
#define N 3200000
#define lowbit(x) ((x)&-(x))
using namespace std;
int n,d[N],f[N];
int ans;
vector<int>a[N];
int t[N]; 
namespace bit{
	int t[N];
	int insert(int x,int a){
		x=n-x+1;
		for(int i=x;i<=n;i+=lowbit(i))t[i]+=a;
		return 0;
	}
	int query(int x){
		x=n-x+1;
		int ans=0;
		for(int i=x;i;i-=lowbit(i))ans+=t[i];
		return ans;
	}
}
inline int read()
{
    int x=0,f=1;
    char ch=getchar();
    while(ch<'0'||ch>'9')
    {
        if(ch=='-')
            f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9')
    {
        x=x*10+ch-'0';
        ch=getchar();
    }
    return x*f;
};
int main(){
	freopen("beacon.in","r",stdin);
	freopen("beacon.out","w",stdout);
	n=read();
	for(int i=1;i<=n;i++)d[i]=read();
	for(int k=3;k<=n;k++){
		int i=k-2;
		int j=i+d[i];
		int l=2*j-i+1;
		l=min(l,n+1);
		a[l].push_back(j);
		bit::insert(min(j,n),1);
		for(int o=0;o<a[k].size();o++){
			bit::insert(min(a[k][o],n),-1);
		}
		f[k]=bit::query(max(k-d[k],1));
	}
//	for(int i=1;i<=n;i++)printf("%d ",f[i]);
//	printf("\n");
//	return 0;
	for(int i=1;i<=n;i++)ans^=f[i];
	printf("%d\n",ans);
}
