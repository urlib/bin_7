#include<bits/stdc++.h>
using namespace std;
long long A,P;
long long phi(long long x){
	long long ans=1;
	for(long long i=2;i*i<=x;i++){
		if(x%i==0)ans*=(i-1),x/=i;
		while(x%i==0)x/=i,ans*=i;
	}
	return ans*max(x-1,1LL);
}
long long power(long long x,long long k,long long P){
	long long ans=1;
	x%=P;
	while(k){
		if(k&1)(ans*=x)%=P;
		(x*=x)%=P;
		k>>=1;
	}
	return ans;
}
int main(){
	scanf("%lld%lld",&A,&P);
	long long B=A+P*phi(P);
	printf("%lld\n",B);
	return 0;
//	scanf("%lld\n",&P);
//	printf("%lld %lld\n",P,phi(P));
//	return 0;
	printf("%lld %lld\n",power(A,B,P),power(B,A,P));
} 
