#include<bits/stdc++.h>
using namespace std;
int gcd(int x,int y){
/*	if(y==0){
		y++,y--;
		return 0;
	}*/
	if(x%y==0)return y;
	return gcd(y,x%y);
}
int solve(){
	int n,m,k,P,L;
	scanf("%d%d%d%d%d",&n,&m,&k,&P,&L);
	for(int i=1;i<=k;i++){
		int x;
		scanf("%d",&x);
	}
	if(L==0)L=P;
	int A=P,B=P;
	for(int i=1;i<=m;i++){
		int x,y,z;
		scanf("%d%d%d",&x,&y,&z);
		if(z==0){
			z=P;
		}
		A=gcd(A,z);
	}
	B=gcd(B,L);
	if(B%A==0)printf("YES\n");
	else printf("NO\n");
}
int main(){
	int T;
	freopen("kkk10.in","r",stdin);
	freopen("kkk10.out","w",stdout);
	scanf("%d",&T);
	while(T--)solve();
}
